<?php
session_start();
include('db_connect.php');

$emailRegex = "/^[a-zA-Z0-9_@.]{3,50}$/"; 
$idRegex = "/^[0-9]{6,15}$/"; 
$passwordRegex = "/^[a-zA-Z0-9!@#$%^&*]{6,20}$/";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $id = $_POST['id'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $errors = [];

    if (!preg_match($emailRegex, $email)) {
        $errors[] = "❌ Invalid email.";
    }

    if (!preg_match($idRegex, $id)) {
        $errors[] = "❌ Invalid ID.";
    }

    if (!preg_match($passwordRegex, $password)) {
        $errors[] = "❌ Invalid password.";
    }

    if (empty($role)) {
        $errors[] = "❌ Please select a role.";
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND user_id = ?");
        $stmt->bind_param("ss", $email, $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();

            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $user['full_name'];
                $_SESSION['role'] = $role;
                $_SESSION['user_id'] = $user['user_id'];

                header("Location: student_dashboard.php");
                exit();
            } else {
                echo "<script>alert('❌ Incorrect password.');</script>";
            }
        } else {
            echo "<script>alert('❌ No matching user found.');</script>";
        }

        $stmt->close();
    } else {
        foreach ($errors as $error) {
            echo "<script>alert('$error');</script>";
        }
    }
}
?>
