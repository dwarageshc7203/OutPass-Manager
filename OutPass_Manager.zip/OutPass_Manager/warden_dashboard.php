<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Warden Dashboard | Outpass Manager</title>
    <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/10799/10799971.png">
    <link rel="stylesheet" href="warden_dashboard.css">
    
    <!-- Google Fonts -->
     
    <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poetsen+One&display=swap" rel="stylesheet">


        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Lilita+One&display=swap" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Special+Gothic+Expanded+One&display=swap" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Winky+Rough:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap" rel="stylesheet">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Poetsen+One&family=Lilita+One&family=Special+Gothic+Expanded+One&family=Winky+Rough:ital,wght@0,300..900;1,300..900&family=Pacifico&family=Lato:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
</head>
<body>
    <div id="wrapper">
        <header>
            <div id="logo"><div id="weblogo"></div>OUT PASS MANAGER</div>
            <nav>
                <ul>
                    <li class="page"><a href="homepage.html">Home</a></li>
                    <li class="page"><a href="logout.php">Logout</a></li>
                    <li class="page" id="contacts">Contacts</li>
                </ul>
            </nav>
        </header>

        <section>
            <div id="dashboard">
                <h1>Welcome, Warden</h1>
                <p>Below are all student outpass requests:</p>

                <table>
                    <thead>
                        <tr>
                            <th>Roll No</th>
                            <th>Name</th>
                            <th>Block No</th>
                            <th>Out Date</th>
                            <th>In Date</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Approve</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $conn = new mysqli("localhost", "root", "", "outpass_manager");
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        $sql = "SELECT * FROM outpass_requests";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$row['rollno']}</td>
                                    <td>{$row['name']}</td>
                                    <td>{$row['blockno']}</td>
                                    <td>{$row['out_date']}</td>
                                    <td>{$row['in_date']}</td>
                                    <td>{$row['reason']}</td>
                                    <td>{$row['status']}</td>
                                    <td>
                                        <form method='POST' action='approve_request.php'>
                                            <input type='hidden' name='request_id' value='{$row['id']}'>
                                            <button class='approve-btn' type='submit'>Approve</button>
                                        </form>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='8'>No requests found.</td></tr>";
                        }
                        $conn->close();
                        ?>
                    </tbody>
                </table>
            </div>
        </section>

        <footer>
            <div id="made_by">Crafted by</div>
            <div class="founders">DWARAGESH C
                <ul class="links">
                    <li><a href="#"><img src="https://freepngimg.com/download/gmail/66428-icons-computer-google-email-gmail-free-transparent-image-hq.png"></a></li>
                    <li><a href="https://github.com/dwarageshc7203"><img src="https://pngimg.com/uploads/github/github_PNG80.png"></a></li>
                    <li><a href="https://www.linkedin.com/in/dwarageshc/"><img src="https://itcnet.gr/wp-content/uploads/2020/09/Linkedin-logo-on-transparent-Background-PNG--1024x1024.png"></a></li>
                </ul>
            </div>
            <div class="founders">SRIDEV B
                <ul class="links">
                    <li><a href="#"><img src="https://freepngimg.com/download/gmail/66428-icons-computer-google-email-gmail-free-transparent-image-hq.png"></a></li>
                    <li><a href="https://github.com/SRIDEV20"><img src="https://pngimg.com/uploads/github/github_PNG80.png"></a></li>
                    <li><a href="https://www.linkedin.com/in/sri-dev-58aa4434a/"><img src="https://itcnet.gr/wp-content/uploads/2020/09/Linkedin-logo-on-transparent-Background-PNG--1024x1024.png"></a></li>
                </ul>
            </div>
        </footer>
    </div>

    <script src="warden_dashboard.js"></script>
</body>
</html>
