document.querySelectorAll('.download-link').forEach(link => {
    link.addEventListener('click', function (e) {
      e.preventDefault();
      const outpass = JSON.parse(this.getAttribute('data-outpass'));
  
      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();
  
      doc.setFontSize(16);
      doc.text("Outpass Details", 20, 20);
      doc.setFontSize(12);
  
      let y = 30;
      for (const key in outpass) {
        doc.text(`${key}: ${outpass[key]}`, 20, y);
        y += 10;
      }
  
      doc.save(`Outpass_ID_${outpass.id}.pdf`);
    });
  });
  

  window.addEventListener("DOMContentLoaded", function () {
    const contacts = document.getElementById("contacts");
    const footer = document.querySelector("footer");
  
    contacts.addEventListener("click", function () {
      footer.scrollIntoView({ behavior: "smooth" });
    });
  });