<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = "localhost";  // Use 127.0.0.1 or localhost (both should work)
$user = "root";        // MySQL username
$password = ""; // MySQL password you set
$dbname = "outpass_manager";   // Database name

// Create connection
$conn = mysqli_connect($host, $user, $password, $dbname);

// Check connection
if (!$conn) {
    die("❌ Connection failed: " . mysqli_connect_error());
}
echo "✅ Connected to MySQL successfully!";
?>
