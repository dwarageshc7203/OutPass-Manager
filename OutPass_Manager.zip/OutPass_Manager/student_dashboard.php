<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
include 'db_connect.php';

// Alter column if needed
$sql = "ALTER TABLE outpass_requests MODIFY COLUMN user_id BIGINT UNSIGNED NOT NULL";
$conn->query($sql);

// Check login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['username'])) {
    die("❌ User not logged in.");
}

$user_id = intval($_SESSION['user_id']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destination = $_POST['destination'];
    $reason = $_POST['reason'];
    $from_date = $_POST['from_date'];
    $to_date = $_POST['to_date'];
    $transport_mode = $_POST['transport'];
    $name = $_SESSION['username'];
    $rollno = $_POST['rollno'] ?? null;
    $blockno = $_POST['blockno'] ?? null;

    $stmt = $conn->prepare("INSERT INTO outpass_requests (user_id, destination, reason, from_date, to_date, transport_mode, name, rollno, blockno, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending')");
    $stmt->bind_param("issssssss", $user_id, $destination, $reason, $from_date, $to_date, $transport_mode, $name, $rollno, $blockno);

    if ($stmt->execute()) {
        $_SESSION['success_message'] = "✅ Outpass request submitted successfully!";
    } else {
        $_SESSION['error_message'] = "❌ Error: " . $stmt->error;
    }

    $stmt->close();
    header("Location: student_dashboard.php");
    exit();
}

$stmt = $conn->prepare("SELECT * FROM outpass_requests WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

// Output the HTML
include 'student_dashboard.html';
?>
