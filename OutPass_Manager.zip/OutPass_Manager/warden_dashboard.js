// Placeholder for future JS functionality
console.log("Warden dashboard loaded.");
document.addEventListener("DOMContentLoaded", () => {
    const contactBtn = document.getElementById("contacts");
    const footer = document.querySelector("footer");

    contactBtn.addEventListener("click", () => {
        footer.scrollIntoView({ behavior: "smooth" });
    });
});
