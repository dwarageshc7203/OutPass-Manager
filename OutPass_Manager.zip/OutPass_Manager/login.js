document.addEventListener("DOMContentLoaded", () => {
    console.log("Login Page Loaded");

    // Add interactivity or client-side validation here if needed
});

window.addEventListener("DOMContentLoaded", function () {
    const contacts = document.getElementById("contacts");
    const footer = document.querySelector("footer");
  
    contacts.addEventListener("click", function () {
        console.log("scrolling");
      footer.scrollIntoView({ behavior: "smooth" });
    });
  });