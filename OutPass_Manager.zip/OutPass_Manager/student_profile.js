// You can expand this later
console.log("Student profile page loaded.");

document.addEventListener("DOMContentLoaded", () => {
    console.log("Student Profile Page Loaded");
});

window.addEventListener("DOMContentLoaded", function () {
    const contacts = document.getElementById("contacts");
    const footer = document.querySelector("footer");

    contacts.addEventListener("click", function () {
        console.log("Scrolling to contacts");
        footer.scrollIntoView({ behavior: "smooth" });
    });
});
