<?php
session_start();
include("db_connect.php");

// TEMPORARILY DISABLE LOGIN REQUIREMENT
// if (!isset($_SESSION['user_id'])) {
//     header("Location: login.php");
//     exit();
// }

// Use a default user_id for testing
$user_id = $_SESSION['user_id'] ?? 'test_user';

// Handle update form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $room_no = $_POST['room_no'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $guardian_name = $_POST['guardian_name'];
    $guardian_phone = $_POST['guardian_phone'];
    $address = $_POST['address'];

    // Check if user already has a profile
    $check = $conn->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
    $check->bind_param("s", $user_id);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        // Update existing profile
        $stmt = $conn->prepare("UPDATE user_profiles SET room_no=?, dob=?, gender=?, guardian_name=?, guardian_phone=?, address=? WHERE user_id=?");
        $stmt->bind_param("sssssss", $room_no, $dob, $gender, $guardian_name, $guardian_phone, $address, $user_id);
    } else {
        // Insert new profile
        $stmt = $conn->prepare("INSERT INTO user_profiles (user_id, room_no, dob, gender, guardian_name, guardian_phone, address) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $user_id, $room_no, $dob, $gender, $guardian_name, $guardian_phone, $address);
    }

    if ($stmt->execute()) {
        $message = "✅ Profile updated successfully!";
    } else {
        $message = "❌ Error updating profile.";
    }

    $stmt->close();
    $check->close();
}

// Fetch user and profile data
$userQuery = $conn->prepare("SELECT full_name, email, phone FROM users WHERE user_id = ?");
$userQuery->bind_param("s", $user_id);
$userQuery->execute();
$userResult = $userQuery->get_result();
$user = $userResult->fetch_assoc();

$profileQuery = $conn->prepare("SELECT * FROM user_profiles WHERE user_id = ?");
$profileQuery->bind_param("s", $user_id);
$profileQuery->execute();
$profileResult = $profileQuery->get_result();
$profile = $profileResult->fetch_assoc();

$conn->close();
?>

<?php include("student_profile.html"); ?>
